# Email Follow-Up Assistant — Supabase-only edition

Same tool, but nothing runs on Railway/Render. The background watching and
follow-up sending happen inside **Supabase Edge Functions**, triggered by
**pg_cron** — both included on Supabase's free tier. The dashboard is a
static HTML page that talks to Supabase directly from your browser, so you
can host it anywhere free (or just open the file locally).

**Cost: $0/month**, as long as you stay within Supabase's free tier limits
(plenty for a personal contact list).

## What you need installed
- [Supabase CLI](https://supabase.com/docs/guides/cli/getting-started) — used once to deploy the functions
- A terminal

## 1. Link the CLI to your project
```
cd email-followup-supabase
supabase login
supabase link --project-ref gytcjlbkmnhnpycyisib
```

## 2. Run the database migrations
Easiest: open **Supabase Dashboard → SQL Editor**, and run the contents of
`supabase/migrations/0001_schema.sql`, then `0002_cron.sql`, in that order.

(Or, if you're comfortable with the CLI: `supabase db push`.)

## 3. Set the Edge Function secrets
These are separate from your `.env` — Edge Functions read secrets set via
the CLI, not a local file:
```
supabase secrets set GOOGLE_CLIENT_ID=625331772715-o3ik8vfink3pequ2ahvcu11hqb6ceii3.apps.googleusercontent.com
supabase secrets set GOOGLE_CLIENT_SECRET=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
supabase secrets set GOOGLE_REDIRECT_URI=https://gytcjlbkmnhnpycyisib.supabase.co/functions/v1/oauth-callback
supabase secrets set APP_SECRET=pmDeNmIpT5mms7ByUOOoadlq2cx06QBHkutwHBgcH8o
supabase secrets set SITE_URL=https://your-frontend-url-once-you-have-one
```
(`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected automatically
by Supabase — you don't set those yourself.)

## 4. Deploy the functions
```
supabase functions deploy oauth-callback
supabase functions deploy oauth-status
supabase functions deploy send-campaign
supabase functions deploy check-replies
supabase functions deploy send-followups
```

## 5. Authorize the redirect URI in Google Cloud Console
1. [console.cloud.google.com/apis/credentials](https://console.cloud.google.com/apis/credentials) → your OAuth client (`goschol-outreach`)
2. Under **Authorized redirect URIs**, add exactly:
   `https://gytcjlbkmnhnpycyisib.supabase.co/functions/v1/oauth-callback`
3. Make sure your Google account is under **Test users** on the OAuth
   consent screen (if it's still in Testing mode).

## 6. Host the frontend (`public/` folder)
Pick whichever is easiest — all free:
- **Just open it locally**: double-click `public/index.html`. Works fine
  since it talks straight to Supabase; no server needed. Simplest option
  if you're the only user.
- **GitHub Pages**: push the `public/` folder to a repo, enable Pages on
  it in repo Settings.
- **Netlify / Vercel free tier**: drag-and-drop the `public/` folder in
  their dashboard, or connect the GitHub repo.

`public/config.js` already has your real project values filled in — no
editing needed unless you rotate a key later.

## 7. Use it
Open the frontend, click **Connect Gmail**, upload your contact list,
write your email, hit send. From here on, Supabase itself checks for
replies every 15 minutes and sends due follow-ups every hour — with no
process of yours needing to stay running anywhere.

## Checking that the background jobs are actually running
In the Supabase SQL Editor:
```sql
select * from cron.job;                                   -- see scheduled jobs
select * from cron.job_run_details order by start_time desc limit 20;  -- run history
```
You can also check **Edge Functions → Logs** in the Supabase dashboard for
each function's execution logs.

## Notes / limits
- This app is intentionally single-user, matching what you asked for.
- The `APP_SECRET` header is a light gate on the Edge Functions, not real
  authentication — fine for a personal tool whose URL you don't share, not
  a substitute for login if you ever make this public.
- Gmail's sending limit is 500/day for a regular Gmail account (2,000 for
  Workspace).
- Since your Supabase and Google keys were shared in the chat that built
  this, consider rotating the Supabase `service_role` key and the Google
  client secret once everything's confirmed working.
