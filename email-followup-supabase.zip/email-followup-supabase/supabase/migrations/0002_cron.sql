-- Run this AFTER you've deployed the edge functions (`supabase functions deploy`)
-- and set the APP_SECRET secret. Run in the Supabase SQL Editor.

create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Every 15 minutes: check the inbox for replies.
select cron.schedule(
  'check-replies-job',
  '*/15 * * * *',
  $$
  select net.http_post(
    url := 'https://gytcjlbkmnhnpycyisib.supabase.co/functions/v1/check-replies',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-app-secret', 'pmDeNmIpT5mms7ByUOOoadlq2cx06QBHkutwHBgcH8o'
    ),
    body := '{}'::jsonb
  );
  $$
);

-- Every hour: send any follow-ups that are due.
select cron.schedule(
  'send-followups-job',
  '0 * * * *',
  $$
  select net.http_post(
    url := 'https://gytcjlbkmnhnpycyisib.supabase.co/functions/v1/send-followups',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-app-secret', 'pmDeNmIpT5mms7ByUOOoadlq2cx06QBHkutwHBgcH8o'
    ),
    body := '{}'::jsonb
  );
  $$
);

-- To check on scheduled jobs later:
--   select * from cron.job;
-- To see run history:
--   select * from cron.job_run_details order by start_time desc limit 20;
-- To remove a job:
--   select cron.unschedule('check-replies-job');
