-- Run in Supabase SQL Editor, or via `supabase db push` if using the CLI.

create extension if not exists pgcrypto;

create table if not exists contacts (
  id uuid primary key default gen_random_uuid(),
  name text,
  email text unique not null,
  school text,
  business text,
  extra jsonb default '{}'::jsonb,
  status text default 'pending',            -- pending | sent | replied | failed
  gmail_thread_id text,
  gmail_message_id text,
  gmail_rfc_message_id text,
  sent_at timestamptz,
  follow_up_count int default 0,
  last_follow_up_at timestamptz,
  replied_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists campaign_settings (
  id int primary key default 1,
  subject text,
  body text,
  follow_up_subject text,
  follow_up_body text,
  follow_up_days int default 3,
  follow_up_days_2 int default 3,
  max_follow_ups int default 1,
  active boolean default false,
  constraint single_row check (id = 1)
);

create table if not exists oauth_tokens (
  id int primary key default 1,
  refresh_token text,
  access_token text,
  expiry timestamptz,
  connected_email text,
  constraint single_row_tokens check (id = 1)
);

-- The static frontend talks to Supabase directly using the public anon key,
-- so contacts/settings need policies allowing that (this is a single-user
-- personal tool, so "anyone with the anon key" is just you).
alter table contacts enable row level security;
create policy "anon full access contacts" on contacts
  for all using (true) with check (true) to anon;

alter table campaign_settings enable row level security;
create policy "anon full access campaign_settings" on campaign_settings
  for all using (true) with check (true) to anon;

-- oauth_tokens holds your Gmail refresh token — it gets RLS enabled but NO
-- policy for anon, so the anon key (used in the browser) can never read or
-- write it. Only the service_role key (used inside Edge Functions) can
-- touch this table, since service_role bypasses RLS entirely.
alter table oauth_tokens enable row level security;
