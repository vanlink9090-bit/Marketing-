import { createClient } from 'jsr:@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
import { refreshAccessToken, hasReplied } from '../_shared/gmail.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const appSecret = Deno.env.get('APP_SECRET');
  if (appSecret && req.headers.get('x-app-secret') !== appSecret) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: tokenRow } = await supabase.from('oauth_tokens').select('*').eq('id', 1).maybeSingle();
    if (!tokenRow || !tokenRow.refresh_token) {
      return new Response(JSON.stringify({ checked: 0, note: 'Gmail not connected' }), { headers: corsHeaders });
    }

    const clientId = Deno.env.get('GOOGLE_CLIENT_ID')!;
    const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')!;
    const { access_token: accessToken } = await refreshAccessToken(tokenRow.refresh_token, clientId, clientSecret);

    const { data: contacts, error } = await supabase.from('contacts').select('*').eq('status', 'sent');
    if (error) throw error;

    let repliedCount = 0;

    for (const contact of contacts) {
      try {
        const replied = await hasReplied(accessToken, contact.email, contact.sent_at);
        if (replied) {
          await supabase.from('contacts').update({
            status: 'replied',
            replied_at: new Date().toISOString(),
          }).eq('id', contact.id);
          repliedCount++;
        }
      } catch (err) {
        console.error(`Reply check failed for ${contact.email}:`, err);
      }
    }

    return new Response(JSON.stringify({ checked: contacts.length, newlyReplied: repliedCount }), { headers: corsHeaders });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: (err as Error).message }), { status: 500, headers: corsHeaders });
  }
});
