import { createClient } from 'jsr:@supabase/supabase-js@2';
import { exchangeCodeForTokens, getUserEmail } from '../_shared/gmail.ts';

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  if (!code) return new Response('Missing code', { status: 400 });

  try {
    const clientId = Deno.env.get('GOOGLE_CLIENT_ID')!;
    const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')!;
    const redirectUri = Deno.env.get('GOOGLE_REDIRECT_URI')!;

    const tokens = await exchangeCodeForTokens(code, clientId, clientSecret, redirectUri);
    const email = await getUserEmail(tokens.access_token);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Google only sends refresh_token on the first consent. If this is a
    // reconnect and none came back, keep the previously stored one.
    let refreshToken = tokens.refresh_token;
    if (!refreshToken) {
      const { data: existing } = await supabase.from('oauth_tokens').select('refresh_token').eq('id', 1).maybeSingle();
      refreshToken = existing?.refresh_token || null;
    }

    await supabase.from('oauth_tokens').upsert({
      id: 1,
      refresh_token: refreshToken,
      access_token: tokens.access_token,
      expiry: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
      connected_email: email,
    }, { onConflict: 'id', ignoreDuplicates: false });

    const siteUrl = Deno.env.get('SITE_URL') || '';
    return new Response(
      `<html><body style="font-family:sans-serif;text-align:center;padding:60px">
        <h2>Connected: ${email}</h2>
        <p>You can close this tab and go back to the dashboard.</p>
        ${siteUrl ? `<script>setTimeout(() => window.location.href = ${JSON.stringify(siteUrl)}, 1500)</script>` : ''}
      </body></html>`,
      { headers: { 'Content-Type': 'text/html' } }
    );
  } catch (err) {
    console.error(err);
    return new Response('OAuth error: ' + (err as Error).message, { status: 500 });
  }
});
