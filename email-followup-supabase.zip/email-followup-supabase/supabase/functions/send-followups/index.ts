import { createClient } from 'jsr:@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
import { refreshAccessToken, hasReplied, sendGmailMessage, fillTemplate } from '../_shared/gmail.ts';

const DAY_MS = 24 * 60 * 60 * 1000;

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const appSecret = Deno.env.get('APP_SECRET');
  if (appSecret && req.headers.get('x-app-secret') !== appSecret) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: tokenRow } = await supabase.from('oauth_tokens').select('*').eq('id', 1).maybeSingle();
    if (!tokenRow || !tokenRow.refresh_token) {
      return new Response(JSON.stringify({ sent: 0, note: 'Gmail not connected' }), { headers: corsHeaders });
    }

    const { data: settings } = await supabase.from('campaign_settings').select('*').eq('id', 1).maybeSingle();
    const maxFollowUps = settings?.max_follow_ups || 0;
    if (!settings || !settings.follow_up_subject || !settings.follow_up_body || maxFollowUps < 1) {
      return new Response(JSON.stringify({ sent: 0, note: 'No follow-up configured' }), { headers: corsHeaders });
    }

    const clientId = Deno.env.get('GOOGLE_CLIENT_ID')!;
    const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')!;
    const { access_token: accessToken } = await refreshAccessToken(tokenRow.refresh_token, clientId, clientSecret);

    const { data: contacts, error } = await supabase
      .from('contacts')
      .select('*')
      .eq('status', 'sent')
      .lt('follow_up_count', maxFollowUps);
    if (error) throw error;

    const now = Date.now();
    let sentCount = 0;

    for (const contact of contacts) {
      try {
        const replied = await hasReplied(accessToken, contact.email, contact.sent_at);
        if (replied) {
          await supabase.from('contacts').update({
            status: 'replied',
            replied_at: new Date().toISOString(),
          }).eq('id', contact.id);
          continue;
        }

        const waitDays = contact.follow_up_count === 0
          ? (settings.follow_up_days || 3)
          : (settings.follow_up_days_2 || settings.follow_up_days || 3);

        const lastActionAt = new Date(contact.last_follow_up_at || contact.sent_at).getTime();
        const dueAt = lastActionAt + waitDays * DAY_MS;
        if (now < dueAt) continue;

        const subject = fillTemplate(settings.follow_up_subject, contact);
        const body = fillTemplate(settings.follow_up_body, contact);

        const result = await sendGmailMessage(accessToken, {
          to: contact.email,
          from: tokenRow.connected_email,
          subject,
          body,
          threadId: contact.gmail_thread_id,
          inReplyTo: contact.gmail_rfc_message_id,
          references: contact.gmail_rfc_message_id,
        });

        await supabase.from('contacts').update({
          follow_up_count: contact.follow_up_count + 1,
          last_follow_up_at: new Date().toISOString(),
          gmail_message_id: result.id,
        }).eq('id', contact.id);

        sentCount++;
      } catch (err) {
        console.error(`Follow-up failed for ${contact.email}:`, err);
      }
    }

    return new Response(JSON.stringify({ sent: sentCount }), { headers: corsHeaders });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: (err as Error).message }), { status: 500, headers: corsHeaders });
  }
});
