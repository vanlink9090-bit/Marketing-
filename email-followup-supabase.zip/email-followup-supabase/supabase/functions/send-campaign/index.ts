import { createClient } from 'jsr:@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
import { refreshAccessToken, sendGmailMessage, getRfcMessageId, fillTemplate } from '../_shared/gmail.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const appSecret = Deno.env.get('APP_SECRET');
  if (appSecret && req.headers.get('x-app-secret') !== appSecret) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: tokenRow } = await supabase.from('oauth_tokens').select('*').eq('id', 1).maybeSingle();
    if (!tokenRow || !tokenRow.refresh_token) {
      return new Response(JSON.stringify({ error: 'Gmail is not connected yet' }), { status: 400, headers: corsHeaders });
    }

    const clientId = Deno.env.get('GOOGLE_CLIENT_ID')!;
    const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')!;
    const { access_token: accessToken } = await refreshAccessToken(tokenRow.refresh_token, clientId, clientSecret);

    const { data: settings } = await supabase.from('campaign_settings').select('*').eq('id', 1).maybeSingle();
    if (!settings || !settings.subject || !settings.body) {
      return new Response(JSON.stringify({ error: 'Set an email subject and body first' }), { status: 400, headers: corsHeaders });
    }

    const { data: contacts, error } = await supabase.from('contacts').select('*').eq('status', 'pending');
    if (error) throw error;

    let sent = 0;
    const failures: string[] = [];

    for (const contact of contacts) {
      try {
        const subject = fillTemplate(settings.subject, contact);
        const body = fillTemplate(settings.body, contact);
        const result = await sendGmailMessage(accessToken, { to: contact.email, from: tokenRow.connected_email, subject, body });
        const rfcMessageId = await getRfcMessageId(accessToken, result.id).catch(() => null);

        await supabase.from('contacts').update({
          status: 'sent',
          sent_at: new Date().toISOString(),
          gmail_thread_id: result.threadId,
          gmail_message_id: result.id,
          gmail_rfc_message_id: rfcMessageId,
        }).eq('id', contact.id);

        sent++;
      } catch (sendErr) {
        console.error('Failed to send to', contact.email, sendErr);
        failures.push(contact.email);
        await supabase.from('contacts').update({ status: 'failed' }).eq('id', contact.id);
      }
    }

    await supabase.from('campaign_settings').update({ active: true }).eq('id', 1);

    return new Response(JSON.stringify({ sent, failed: failures.length, failures }), { headers: corsHeaders });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: (err as Error).message }), { status: 500, headers: corsHeaders });
  }
});
