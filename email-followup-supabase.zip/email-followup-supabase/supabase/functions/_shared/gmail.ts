// Minimal Gmail API client built on plain fetch — works in the Deno Edge
// Function runtime, which can't use the Node-only `googleapis` package.

export async function refreshAccessToken(refreshToken: string, clientId: string, clientSecret: string) {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });
  if (!res.ok) throw new Error(`Token refresh failed: ${await res.text()}`);
  return res.json(); // { access_token, expires_in, scope, token_type }
}

export async function exchangeCodeForTokens(code: string, clientId: string, clientSecret: string, redirectUri: string) {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  });
  if (!res.ok) throw new Error(`Code exchange failed: ${await res.text()}`);
  return res.json(); // { access_token, refresh_token, expires_in, ... }
}

export async function getUserEmail(accessToken: string) {
  const res = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`userinfo failed: ${await res.text()}`);
  const data = await res.json();
  return data.email as string;
}

function base64url(input: string) {
  const bytes = new TextEncoder().encode(input);
  let binary = '';
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function buildRawMessage(opts: {
  to: string; from: string; subject: string; body: string;
  inReplyTo?: string | null; references?: string | null;
}) {
  const headers = [
    `To: ${opts.to}`,
    `From: ${opts.from}`,
    `Subject: ${opts.subject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
  ];
  if (opts.inReplyTo) headers.push(`In-Reply-To: ${opts.inReplyTo}`);
  if (opts.references) headers.push(`References: ${opts.references}`);
  const raw = headers.join('\r\n') + '\r\n\r\n' + opts.body;
  return base64url(raw);
}

export async function sendGmailMessage(accessToken: string, opts: {
  to: string; from: string; subject: string; body: string;
  threadId?: string | null; inReplyTo?: string | null; references?: string | null;
}) {
  const raw = buildRawMessage(opts);
  const res = await fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ raw, threadId: opts.threadId || undefined }),
  });
  if (!res.ok) throw new Error(`Gmail send failed: ${await res.text()}`);
  return res.json(); // { id, threadId, ... }
}

export async function hasReplied(accessToken: string, contactEmail: string, sentAtISO: string) {
  const afterEpoch = Math.floor(new Date(sentAtISO).getTime() / 1000);
  const q = encodeURIComponent(`from:${contactEmail} after:${afterEpoch}`);
  const res = await fetch(`https://www.googleapis.com/gmail/v1/users/me/messages?q=${q}&maxResults=1`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Gmail search failed: ${await res.text()}`);
  const data = await res.json();
  return !!(data.messages && data.messages.length > 0);
}

export async function getRfcMessageId(accessToken: string, gmailMessageId: string) {
  const res = await fetch(
    `https://www.googleapis.com/gmail/v1/users/me/messages/${gmailMessageId}?format=metadata&metadataHeaders=Message-ID`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!res.ok) return null;
  const data = await res.json();
  const header = (data.payload?.headers || []).find((h: any) => h.name === 'Message-ID');
  return header ? header.value : null;
}

export function fillTemplate(str: string, contact: Record<string, any>) {
  if (!str) return '';
  const data: Record<string, any> = {
    name: contact.name || '',
    school: contact.school || '',
    business: contact.business || '',
    email: contact.email || '',
    ...(contact.extra || {}),
  };
  return str.replace(/{{\s*(\w+)\s*}}/g, (m, key) => (data[key] !== undefined && data[key] !== null ? String(data[key]) : m));
}
