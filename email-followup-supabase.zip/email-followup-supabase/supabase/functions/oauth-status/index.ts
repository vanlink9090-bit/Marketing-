import { createClient } from 'jsr:@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const appSecret = Deno.env.get('APP_SECRET');
  if (appSecret && req.headers.get('x-app-secret') !== appSecret) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  const { data } = await supabase.from('oauth_tokens').select('connected_email, refresh_token').eq('id', 1).maybeSingle();
  const connected = !!(data && data.refresh_token);

  return new Response(
    JSON.stringify({ connected, email: connected ? data!.connected_email : null }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
});
